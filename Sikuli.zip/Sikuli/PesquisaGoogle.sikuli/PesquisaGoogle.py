click("1529676008874.png")
wait(2)
type("www.google.com.br" + Key.ENTER)
find("1529676101681.png")
type("Alfresco Share" + Key.ENTER)
click("1529677294679.png")
wait(5)
click("1529677354307.png")



