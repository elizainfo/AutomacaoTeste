click("1529677418875.png")
wait(2)
type("fospar.dev.roma.imperio.com.br")
find("1529679803892.png")
type(Key.ENTER)
wait(3)
click("1529681973549.png")
type("IMPERIO" + Key.TAB)
find("1529677566284.png")
type("imperio@123")        
click("1529682034119.png")
wait(6)
click("1529682342612.png")
find("1529682396997.png")
click("1529682410491.png")
click("1529682429402.png")





